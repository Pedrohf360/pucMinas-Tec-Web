// JavaScript Document


//Variáveis


//Aguardando página ser carregada
$(document).ready(function(){
	
	//Quando clicar em um botão, disparar um evento para esconder uma div
	$("#bt_Carregar").click(function(){
		
		$("#conteudo").fadeOut(500,function(){
			
			$(".carregar").fadeIn(500, function(){

				var id = $('#id_produto').val()
				
				if(id == ""){
					id = true;
				}
				console.log(id);
				
				$.ajax({
				  method: "POST",
				  url: "produtos.php",
				  data: { id: id }
				})
				.done(function( retorno ) {
					
					if(retorno ==""){
						$("#conteudo").html("Produto não encontrado!");
					}else{
						$("#conteudo").html(retorno);
					}
					
					$(".carregar").fadeOut(500, function(){
						
						$("#conteudo").fadeIn(500);
						
					});					
					
				});
				
			});
			
		});	
		
	});
	
	
});

/*
$.ajax({
  method: "POST",
  url: "some.php",
  data: { name: "John", location: "Boston" }
})
.done(function( msg ) {
alert( "Data Saved: " + msg );
});*/
