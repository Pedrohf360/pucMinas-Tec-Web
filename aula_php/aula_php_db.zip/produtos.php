<?php

if(empty($_POST['id'])){
	echo "Esse script nao pode ser acessado diretamente!";
}else{
	
	$id_produto = $_POST['id'];
		
	//Primeiro conectar ao banco
	$conexao = mysqli_connect("localhost","root","root","tecweb_ajax");
	
	if(!$conexao){
		echo "Erro ao conectar no banco!";
	}else{
		if($id_produto == "true"){
			$sql = "SELECT * FROM produtos;";
		}else{
			$sql = "SELECT * FROM produtos WHERE id=".$id_produto.";";
		}
		
		$query = mysqli_query($conexao,$sql);
				
		while($dados = mysqli_fetch_array($query)){
			echo "<strong>Produto:</strong> ".$dados['nome']."<br>";
			echo "<br>Foto:<br>";
			echo "<img src='".$dados['url']."' width='200'>";
			echo "<hr>";
		}
		
	}
}
?>